﻿using System.Windows.Controls;

namespace Currencies.Views.Controls
{
    /// <summary>
    /// Interaction logic for CurrenciesControl.xaml
    /// </summary>
    public partial class CurrenciesControl : UserControl
    {
        public CurrenciesControl()
        {
            InitializeComponent();
        }
    }
}